
<?php echo $__env->make('assets.bootstrap', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid d-flex p-0 flex-fill h-100">
        <?php echo $__env->make('templates.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="content p-3 px-4 col-12 col-sm-9 col-md-10">
            <div class="title fs-5 mb-3">
                Diagnosis Kerusakan Komputer <span class="text-muted">| Data Gejala</span>
            </div>

            <table id="example" class="table table-striped border border-1 rounded shadow-sm border-black" style="width:100%">
                <thead>
                    <tr>
                        <th>Id</th>
                        <th>Gejala</th>
                        <th>Nilai CF</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $dataGejala; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($row->id); ?></td>
                            <td><?php echo e($row->gejala); ?></td>
                            <td><?php echo e($row->cf); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Vanness Iwata\Informatika - UMN\Belajar web\UAS_ExpertSystem\resources\views/admin/data_gejala.blade.php ENDPATH**/ ?>