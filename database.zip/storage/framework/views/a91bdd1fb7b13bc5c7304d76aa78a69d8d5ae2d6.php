<?php echo $__env->make("assets/bootstrap", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="../css/main.css">
    <title>Document</title>
    <?php echo $__env->yieldContent('assets'); ?>
</head>
<body>
    <?php echo $__env->make("templates.navbar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container card my-4" style="height:80vh; overflow:auto;">
        <div class="card-header p-5">
            <h3>Mulai Diagnosa</h3>
        </div>
        <form method="POST" action="<?php echo e(route("cf.postmethod")); ?>">
            <?php echo csrf_field(); ?>
            <?php $__currentLoopData = $certainty; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card-body">
                    <h5><?php echo e($c['gejala']); ?></h5>
                    <input class="form-checked-input" type="radio" name="<?php echo e($c['id']); ?>" value="Yes"/>
                    <label for="<?php echo e($c['id']); ?>" class="form-checked-label">Yes</label>
                    <input type="radio" name="<?php echo e($c['id']); ?>" value="No" class="form-checked-input"/>
                    <label for="<?php echo e($c['id']); ?>" class="form-checked-lalbel">No</label>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <a href="/result"><input  class="btn btn-primary mx-3 my-2" type="submit" name="submit" value="Submit"/></a>
        </form>
    </div>
</body>
</html><?php /**PATH D:\Vanness Iwata\Informatika - UMN\Belajar web\UAS_ExpertSystem\resources\views/user/diagnose.blade.php ENDPATH**/ ?>