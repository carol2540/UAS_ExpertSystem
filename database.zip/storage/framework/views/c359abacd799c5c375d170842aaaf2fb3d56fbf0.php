<?php echo $__env->make("assets.bootstrap", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Document</title>
    <link rel="stylesheet" href="../css/main.css">
    <?php echo $__env->yieldContent('assets'); ?>
</head>
<body>
    <?php echo $__env->make("templates.navbar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container card mt-5">
        <div class="card-head">
            <h1 class="p-5">Hasil</h1>
        </div>
        <div class="contenttitle my-3">
            <h3 class="px-3 py-1">Kerusakan :</h3>
        </div>
        <?php $__currentLoopData = $combineCf; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($value == $maxValue): ?>
            <div class="card-body">
                <p><?php echo e($dataKerusakan[$key-1]['Kerusakan']); ?></p>
                <p>Dengan Keyakinan :</p>
                <p><?php echo e($value * 100); ?>%</p>
                <a href="solution/<?php echo e($dataKerusakan[$key-1]['id']); ?>"><button class="btn btn-primary">View Solution</button></a>
            </div>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="contenttitle px-2 my-3">
            <h3 class="px-3 py-1">Kemungkinan Lain :</h3>
        </div>
        <?php $__currentLoopData = $combineCf; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($value != 0): ?>
                <?php if($value != $maxValue): ?>
                <div class="card-body">
                    <p><?php echo e($dataKerusakan[$key-1]['Kerusakan']); ?></p>
                    <p>Dengan Keyakinan :</p>
                    <p><?php echo e($value * 100); ?>%</p>
                    <a href="solution/<?php echo e($dataKerusakan[$key-1]['id']); ?>"><button class="btn btn-primary">View Solution</button></a>
                </div>
                <?php endif; ?>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</body>
</html><?php /**PATH D:\Vanness Iwata\Informatika - UMN\Belajar web\UAS_ExpertSystem\resources\views/user/result.blade.php ENDPATH**/ ?>