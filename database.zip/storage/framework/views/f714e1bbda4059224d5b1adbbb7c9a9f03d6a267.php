<?php echo $__env->make("assets.bootstrap", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Document</title>
    <link rel="stylesheet" href="../css/main.css">
    <?php echo $__env->yieldContent('assets'); ?>
</head>
<body>
    <?php echo $__env->make("templates.navbar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container pt-5">
        <h2>Solusi Untuk Kerusakan "<?php echo e($kerusakan['Kerusakan']); ?>"</h2>
        <div class="card p-5 my-4">
            <h5>Lakukan beberapa langkah dibawah ini:</h5>
            <?php $__currentLoopData = $solusi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <p><?php echo e($s['solution']); ?></p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</body>
</html><?php /**PATH D:\Vanness Iwata\Informatika - UMN\Belajar web\UAS_ExpertSystem\resources\views/user/solution.blade.php ENDPATH**/ ?>