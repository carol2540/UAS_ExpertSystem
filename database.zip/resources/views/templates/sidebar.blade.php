<div class="sidebar col-3 col-md-2 d-none d-sm-block bg-light">
  <ul class="list-group">
      <a href="{{ route('data.gejala') }}" class="list-group-item bg-light link-primary"><i class="bi bi-shield-fill-plus me-1"></i>Data Gejala</a>
      <a href="{{ route('data.kerusakan') }}" class="list-group-item bg-light link-primary"><i class="bi bi-journal-text me-1"></i>Data Kersuakan</a>
  </ul>
</div>
