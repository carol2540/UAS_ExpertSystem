<table id="example" class="table table-striped border border-1 rounded shadow-sm border-black" style="width:100%">
  <thead>
      <tr>
          <th>Name</th>
          <th>Position</th>
          <th>Actions</th>
      </tr>
  </thead>
  <tbody>
      <tr>
          <td>Tiger Nixon</td>
          <td>System Architect</td>
          <td>
              <button class="btn btn-primary">Edit</button>
              <button class="btn btn-danger">Delete</button>
          </td>
      </tr>
      <tr>
          <td>Garrett Winters</td>
          <td>Accountant</td>
          <td>
              <button class="btn btn-primary">Edit</button>
              <button class="btn btn-danger">Delete</button>
          </td>
      </tr>
      <tr>
          <td>Ashton Cox</td>
          <td>Junior Technical Author</td>
          <td>
              <button class="btn btn-primary">Edit</button>
              <button class="btn btn-danger">Delete</button>
          </td>
      </tr>
      <tr>
          <td>Cedric Kelly</td>
          <td>Senior Javascript Developer</td>
          <td>
              <button class="btn btn-primary">Edit</button>
              <button class="btn btn-danger">Delete</button>
          </td>
      </tr>
      <tr>
          <td>Airi Satou</td>
          <td>Accountant</td>
          <td>
              <button class="btn btn-primary">Edit</button>
              <button class="btn btn-danger">Delete</button>
          </td>
      </tr>
      <tr>
          <td>Brielle Williamson</td>
          <td>Integration Specialist</td>
          <td>
              <button class="btn btn-primary">Edit</button>
              <button class="btn btn-danger">Delete</button>
          </td>
      </tr>
      <tr>
          <td>Herrod Chandler</td>
          <td>Sales Assistant</td>
          <td>
              <button class="btn btn-primary">Edit</button>
              <button class="btn btn-danger">Delete</button>
          </td>
      </tr>
      <tr>
          <td>Rhona Davidson</td>
          <td>Integration Specialist</td>
          <td>
              <button class="btn btn-primary">Edit</button>
              <button class="btn btn-danger">Delete</button>
          </td>
      </tr>
      <tr>
          <td>Colleen Hurst</td>
          <td>Javascript Developer</td>
          <td>
              <button class="btn btn-primary">Edit</button>
              <button class="btn btn-danger">Delete</button>
          </td>
      </tr>
      <tr>
          <td>Sonya Frost</td>
          <td>Software Engineer</td>
          <td>
              <button class="btn btn-primary">Edit</button>
              <button class="btn btn-danger">Delete</button>
          </td>
      </tr>
      <tr>
          <td>Jena Gaines</td>
          <td>Office Manager</td>
          <td>
              <button class="btn btn-primary">Edit</button>
              <button class="btn btn-danger">Delete</button>
          </td>
      </tr>
      <tr>
          <td>Quinn Flynn</td>
          <td>Support Lead</td>
          <td>
              <button class="btn btn-primary">Edit</button>
              <button class="btn btn-danger">Delete</button>
          </td>
      </tr>
      <tr>
          <td>Charde Marshall</td>
          <td>Regional Director</td>
          <td>
              <button class="btn btn-primary">Edit</button>
              <button class="btn btn-danger">Delete</button>
          </td>
      </tr>
      <tr>
          <td>Haley Kennedy</td>
          <td>Senior Marketing Designer</td>
          <td>
              <button class="btn btn-primary">Edit</button>
              <button class="btn btn-danger">Delete</button>
          </td>
      </tr>
    </tbody>
    <tfoot>
        <tr>
            <th>Name</th>
            <th>Position</th>
            <th>Actions</th>
        </tr>
    </tfoot>
</table>