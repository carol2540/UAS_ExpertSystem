@include("assets/bootstrap")

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="../css/main.css">
    <title>About</title>
    @yield('assets')
</head>
<body>
    @include("templates.navbar")
    <div>
        Nama  :  Vanness Iwata
        NIM   :  000 000 46190
    </div>
    <div>
        Nama  :  Alan Prastowo
        NIM   :  00000051557
    </div>
    <div>
        Nama  :  Charisma Christ Anugrah
        NIM   :  000 000 43903
    </div>
    <div>
        Nama  :  Klaudius Carol Illona Banu
        NIM   :  000 000 50432
    </div>
    <div>
        Nama  :  Kezia Ivena Tania
        NIM   :  000 000 42845
    </div>
</body>
</html>